public class WAMachineStraight extends SlotMachine {
  public WAMachineStraight() {
    cabinet = "Large";
    display = "reels";
    payment = "bills";
    gpu = "ARM";
    os = "Linux";
  }
}