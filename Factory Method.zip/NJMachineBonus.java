public class NJMachineBonus extends SlotMachine {
  public NJMachineBonus() {
    cabinet = "Large";
    display = "reels";
    payment = "coins";
    gpu = "ARM";
    os = "Windows ME";
  }
}