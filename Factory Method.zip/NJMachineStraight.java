public class NJMachineStraight extends SlotMachine {
  public NJMachineStraight() {
    cabinet = "Small";
    display = "LCD";
    payment = "coins";
    gpu = "ARM";
    os = "Windows ME";
  }
}