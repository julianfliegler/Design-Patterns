public class WAMachineBonus extends SlotMachine {
  public WAMachineBonus() {
    cabinet = "Medium";
    display = "VGA";
    payment = "TicketinTicketout";
    gpu = "ARM";
    os = "Symbian";
  }
}