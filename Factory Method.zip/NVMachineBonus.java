public class NVMachineBonus extends SlotMachine {
  public NVMachineBonus() {
    cabinet = "Small";
    display = "CRT";
    payment = "TicketinTicketout";
    gpu = "X86";
    os = "Linux";
  }
}