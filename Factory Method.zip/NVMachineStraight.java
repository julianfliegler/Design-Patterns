public class NVMachineStraight extends SlotMachine {
  public NVMachineStraight() {
    cabinet = "Large";
    display = "reels";
    payment = "TicketinTicketout";
    gpu = "ARM";
    os = "Linux";
  }
}