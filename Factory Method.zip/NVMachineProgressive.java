public class NVMachineProgressive extends SlotMachine {
  public NVMachineProgressive() {
    cabinet = "Medium";
    display = "LCD";
    payment = "TicketinTicketout";
    gpu = "X77";
    os = "Android";
  }
}