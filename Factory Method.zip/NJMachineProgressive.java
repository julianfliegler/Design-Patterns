public class NJMachineProgressive extends SlotMachine {
  public NJMachineProgressive() {
    cabinet = "Small";
    display = "CRT";
    payment = "bills";
    gpu = "X86";
    os = "Windows XP";
  }
}