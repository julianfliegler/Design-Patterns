public class WAMachineProgressive extends SlotMachine {
  public WAMachineProgressive() {
    cabinet = "Large";
    display = "reels";
    payment = "coins";
    gpu = "ARM";
    os = "Android";
  }
}